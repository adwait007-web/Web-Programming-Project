<?php
session_start();

if (isset($_SESSION["name"]) && issed($_SESSION["phone"]) && issest($_SESSION["email"])){
    $_SESSION["name"] = "name";
    $_SESSION["phone"] = "phone";
    $_SESSION["email"] = "email";
}else{
    header("Location: index1.html");
    exit();
}
session_unset();
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Info entered</title>
</head>
<body>
    <h2>info</h2>
    <p>Name: <?php echo $name; ?></p>
    <p>Phone: <?php echo $phone; ?></p>
    <p>Email id: <?php echo $email; ?></p>
</body>
</html>