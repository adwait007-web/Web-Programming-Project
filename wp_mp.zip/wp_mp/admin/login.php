<!DOCTYPE html>
<html>
<head>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #e6e6fa; 
    }
    form {
        width: 300px;
        margin: 50px auto;
        padding: 20px;
        background-color: #ffffff;
        border: 1px solid #ddd;
        border-radius: 5px;
    }
    table {
        width: 100%;
    }
    caption {
        font-size: 24px;
        text-align: center;
        margin-bottom: 20px;
    }
    td {
        padding: 10px 0;
    }
    input[type="text"], input[type="password"] {
        width: 100%;
        padding: 8px;
        margin: 5px 0;
        border: 1px solid #ddd;
        border-radius: 3px;
    }
    input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin-top: 10px;
        background-color: #add8e6; 
        color: #ffffff;
        border: none;
        border-radius: 3px;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #87ceeb; 
    }
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<form action="home.php" method="post">
<table align="center">
<caption>Login Form</caption>
<tr>
<td>UserName</td>
<td><input type="text" name="username" /></td>
</tr>
<tr>
<td>Password:</td>
<td><input type="password" name="password" /></td>
</tr>
<tr>
<td></td>
<td colspan="2"><input type="submit" name="login" value="login" /></td>
</tr>
</table>
</form>
</body>
</html>
